@extends('partial.base')

@section('title', 'Home Page')

@section('style')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
@endsection

@section('content')

    <div class="w-100 d-flex justify-content-center align-items-center flex-column gap-4" style="min-height: 50vh">
        <h3 class="fw-semibold">Cari Mainan Kesukaanmu Disini!</h3>
        <div class="w-50">
            <form action="{{ route('home.search') }}" class="d-flex justify-content-center align-items-center gap-4">
                @csrf
                <input type="text" class="form-control" placeholder="Cari mainan ..." name="keyword"
                    value="{{ $search ?? '' }}">
                <button class="btn btn-outline-dark">Cari</button>
            </form>
        </div>
    </div>

    <h3 class="mb-4">Rekomendasi</h3>
    <div class="d-flex justify-content-around align-items-center flex-wrap gap-4 my-5">
        @foreach ($foods as $food)
            <div class="card" style="width: 18rem;">
                <img class="card-img-top"  src="{{ $food->image ? asset('img/' . $food->image) : 'https://placehold.co/400?text=Mainan&font=montserrat' }}"
                alt="food-image">
                <div class="card-body">
                    <span class="badge text-bg-primary">{{ $food->category->name }}</span>
                    <h5 class="card-title">{{ $food->name }}</h5>
                    <p class="card-text">{{ Str::limit($food->description, 150, '...') }}</p>
                    <p class="text-semibold text-danger">Rp {{ number_format($food->price) }}</p>
                    <div class="d-flex w-100 justify-content-around align-items-center">
                        <a class="link-dark link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
                            href="{{ route('food.detail', $food) }}">
                            Selengkapnya
                        </a>
                        <a href="#" class="btn btn-dark">Pesan</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection
