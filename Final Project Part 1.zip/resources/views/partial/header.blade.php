<nav class="navbar navbar-expand-lg bg-dark p-4 sticky-top top-0" data-bs-theme="dark">
    <div class="container">
        <a class="navbar-brand" href="{{ route('home') }}">Toko Mainan</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="{{ route('home') }}">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="{{ route('katalog') }}">Katalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="{{ route('about') }}">Tentang Kami</a>
                </li>
            </ul>
            <div class="d-flex justify-content-center align-items-center gap-4">
                @if (Auth::user())
                    <a href="{{ route('checkout') }}" class="text-light">
                        <i class="bi bi-cart"></i>
                    </a>
                    <a href="{{ route('invoice') }}" class="text-light">
                        <i class="bi bi-receipt"></i>
                    </a>
                    <p class="text-light m-0">Hello, {{ Auth::user()->name }}</p>
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="btn btn-outline-light">Logout</button>
                    </form>
                @else
                    <a href="{{ route('login') }}" class="btn btn-outline-light">Masuk</a>
                    <a href="{{ route('register') }}" class="btn btn-outline-light">Daftar</a>
                @endif
            </div>
        </div>
    </div>
    </div>
</nav>
