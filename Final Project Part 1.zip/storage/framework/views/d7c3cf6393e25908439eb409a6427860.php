<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="w-100 d-flex justify-content-center align-items-center flex-column gap-4" style="min-height: 50vh">
        <h3 class="fw-semibold">Cari Mainan Kesukaanmu Disini!</h3>
        <div class="w-50">
            <form action="<?php echo e(route('home.search')); ?>" class="d-flex justify-content-center align-items-center gap-4">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control" placeholder="Cari mainan ..." name="keyword"
                    value="<?php echo e($search ?? ''); ?>">
                <button class="btn btn-outline-dark">Cari</button>
            </form>
        </div>
    </div>

    <h3 class="mb-4">Rekomendasi</h3>
    <div class="d-flex justify-content-around align-items-center flex-wrap gap-4 my-5">
        <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <img class="card-img-top"  src="<?php echo e($food->image ? asset('img/' . $food->image) : 'https://placehold.co/400?text=Mainan&font=montserrat'); ?>"
                alt="food-image">
                <div class="card-body">
                    <span class="badge text-bg-primary"><?php echo e($food->category->name); ?></span>
                    <h5 class="card-title"><?php echo e($food->name); ?></h5>
                    <p class="card-text"><?php echo e(Str::limit($food->description, 150, '...')); ?></p>
                    <p class="text-semibold text-danger">Rp <?php echo e(number_format($food->price)); ?></p>
                    <div class="d-flex w-100 justify-content-around align-items-center">
                        <a class="link-dark link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
                            href="<?php echo e(route('food.detail', $food)); ?>">
                            Selengkapnya
                        </a>
                        <a href="#" class="btn btn-dark">Pesan</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\BINUS\BNCC Back-End Development\Final Project\resources\views/index.blade.php ENDPATH**/ ?>