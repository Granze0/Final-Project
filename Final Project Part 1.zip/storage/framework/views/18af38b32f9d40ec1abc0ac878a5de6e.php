<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center align-items-center flex-column gap-4 vh-100">
        <h3>About Hockten</h3>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptas nihil similique nostrum ullam totam esse, cum laborum soluta suscipit pariatur, id assumenda itaque quidem perferendis numquam consequatur enim quis minus eaque. Ex consectetur quam, sint doloribus amet ipsa! Odit iste minus, accusantium eius voluptates nisi pariatur blanditiis ad non! Vitae amet nesciunt deserunt exercitationem dignissimos modi cum eum eligendi, quaerat error alias optio praesentium adipisci incidunt illum assumenda et minus nulla laborum blanditiis neque? Sapiente, enim necessitatibus. Fuga, nostrum? Quod laborum dolor nemo non odit, qui distinctio optio fugiat minus sequi, pariatur consectetur est eveniet voluptas iste deleniti accusantium iusto numquam officia debitis aliquam. Dicta perferendis ipsum, in cupiditate expedita rem autem non voluptatibus quod nam temporibus sed quo aliquid quas dignissimos possimus veritatis consectetur? Placeat suscipit, perspiciatis, eos doloribus nesciunt cupiditate optio delectus excepturi laborum magni quas. Labore laborum quidem praesentium incidunt facere itaque in soluta veritatis totam dolores?</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dim\OneDrive - Bina Nusantara\code\public\Learning and Training\Regular Class\Tamplate sesi 12\resources\views/nav/about.blade.php ENDPATH**/ ?>