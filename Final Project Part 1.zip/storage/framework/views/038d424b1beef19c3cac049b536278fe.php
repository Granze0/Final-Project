<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('style'); ?>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-crnter align-items-start flex-column gap-4">
        <a class="link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
            href="<?php echo e(route('food.create')); ?>">
            + Add Food
        </a>

        <div class="d-flex justify-content-center align-items-center gap-4">
            <a class="btn btn-outline-dark" href="<?php echo e(route('admin.home')); ?>">All Categories</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="btn btn-outline-dark" href="<?php echo e(route('admin.filter', $category)); ?>"><?php echo e($category->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <h3>Food List</h3>
        <table class="table table-hover table-striped text-center">
            <thead class="table-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Image</th>
                    <th scope="col">Name</th>
                    <th scope="col">Category</th>
                    <th scope="col">Price</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $num = 1; ?>
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="vertical-align: middle">
                        <th scope="row"><?php echo e($num++); ?></th>
                        <td>
                            <img style="width: 150px; height: 150px display:block;" src="<?php echo e($food->image ? asset('img/' . $food->image) : 'https://placehold.co/400/orange/white?text=Food'); ?>"
                                alt="food-image">
                        </td>
                        <td>
                            <a class="link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
                                href="<?php echo e(route('food.detail', $food)); ?>">
                                <?php echo e($food->name); ?>

                            </a>
                        </td>
                        <td><?php echo e($food->category->name); ?></td>
                        <td>Rp <?php echo e(number_format($food->price)); ?></td>
                        <td>
                            <div class="d-flex justify-content-center align-items-center gap-4">
                                <a class="btn btn-outline-primary" href="<?php echo e(route('food.edit', $food)); ?>">
                                    <i class="bi bi-pen"></i>
                                </a>
                                <form action="<?php echo e(route('food.delete', $food)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-outline-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dim\OneDrive - Bina Nusantara\code\public\Learning and Training\Regular Class\Tamplate sesi 12\resources\views/admin/index.blade.php ENDPATH**/ ?>