<?php $__env->startSection('title', 'Menu'); ?>

<?php $__env->startSection('content'); ?>

    <h3 class="mb-4">Choose Your Menu</h3>
    <div class="d-flex justify-content-around align-items-center flex-wrap gap-4">
        
        <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <img class="card-img-top"
                    src="<?php echo e($food->image ? asset('img/' . $food->image) : 'https://placehold.co/400/orange/white?text=Food'); ?>"
                    alt="food-image">
                <div class="card-body">
                    <span class="badge text-bg-primary"><?php echo e($food->category->name); ?></span>
                    <h5 class="card-title"><?php echo e($food->name); ?></h5>
                    <p class="card-text"><?php echo e(Str::limit($food->description, 150, '...')); ?></p>
                    <p class="text-semibold text-danger">Rp <?php echo e(number_format($food->price)); ?></p>
                    <div class="d-flex w-100 justify-content-around align-items-center">
                        <a class="link-dark link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
                            href="<?php echo e(route('food.detail', $food)); ?>">
                            Detail
                        </a>
                        <a href="#" class="btn btn-dark">Order</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($foods->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dim\OneDrive - Bina Nusantara\code\public\Learning and Training\Regular Class\Tamplate sesi 12\resources\views/nav/menu.blade.php ENDPATH**/ ?>