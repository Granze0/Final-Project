<?php $__env->startSection('title', 'Create a Food'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" style="min-height: 100vh">
        <div class="col-4 d-flex justify-content-center align-items-center flex-column border-1 border-end border-dark">
            <div style="max-width: 350px; max-height: 350px">
                <img class="w-100 h-100" style="display:block;" src="<?php echo e($food->image ? asset('img/' . $food->image) : 'https://placehold.co/300/orange/white?text=Food'); ?>"
                alt="food-image">
            </div>
        </div>
        <div class="col-8 d-flex justify-content-center align-items-start flex-column ps-5">
            <h3 class="mb-3">Food Detail</h3>
            <div class="mb-3">
                <h3>Name</h3>
                <p>
                    <?php echo e($food->name); ?>

                </p>
            </div>
            <div class=" mb-3">
                <h3>Category</h3>
                <p>
                    <?php echo e($food->category->name); ?>

                </p>
            </div>
            <div class="mb-3">
                <h3>Description</h3>
                <p>
                    <?php echo e($food->description); ?>

                </p>
            </div>
            <div class="mb-3">
                <h3>Price</h3>
                <p>
                    Rp <?php echo e(number_format($food->price)); ?>

                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dim\OneDrive - Bina Nusantara\code\public\Learning and Training\Regular Class\Tamplate sesi 12\resources\views/admin/food/detail.blade.php ENDPATH**/ ?>