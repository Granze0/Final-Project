<nav class="navbar navbar-expand-lg bg-dark p-4 sticky-top top-0" data-bs-theme="dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Hockten</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="<?php echo e(route('menu')); ?>">Menu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="<?php echo e(route('about')); ?>">About Us</a>
                </li>
            </ul>
            <div class="d-flex justify-content-center align-items-center gap-4">
                <?php if(Auth::user()): ?>
                    <a href="<?php echo e(route('checkout')); ?>" class="text-light">
                        <i class="bi bi-cart"></i>
                    </a>
                    <a href="<?php echo e(route('invoice')); ?>" class="text-light">
                        <i class="bi bi-receipt"></i>
                    </a>
                    <p class="text-light m-0">Hello, <?php echo e(Auth::user()->name); ?></p>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline-light">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-light">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
</nav>
<?php /**PATH C:\Users\Dim\OneDrive - Bina Nusantara\code\public\Learning and Training\Regular Class\Tamplate sesi 12\resources\views/partial/header.blade.php ENDPATH**/ ?>