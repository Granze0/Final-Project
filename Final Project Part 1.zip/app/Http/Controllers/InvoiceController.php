<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function index()
    {
        return view('invoice.index');
    }

    public function detail()
    {
        // your code goes here
    }

    public function store()
    {
        // your code goes here
    }

    public function delete()
    {
        // your code goes here
    }
}
